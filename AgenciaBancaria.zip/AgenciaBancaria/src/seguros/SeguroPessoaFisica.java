package seguros;

import contas.Conta; //Importação do Pacotes contas e da Classe Conta. (Link)

public class SeguroPessoaFisica extends Conta { // adicionar "extends Conta" em caso de Protected

	public static void main(String[] args) {

		// Utilizar objeto SeguroPessoaFisica herança (extends classe Conta)
		SeguroPessoaFisica cc3 = new SeguroPessoaFisica();
		cc3.setCliente("Maxim Vengerov");
		cc3.setSaldo(500);
		System.out.println("Cliente: " + cc3.getCliente());
		cc3.exibirSaldo();

	}

}




